
document.addEventListener('DOMContentLoaded', function () {
  const botaoAgendar = document.getElementById('btn-agendar');
  const formAgendamento = document.getElementById('form-agendamento');

  botaoAgendar.addEventListener('click', function (e) {
    e.preventDefault();
    formAgendamento.classList.toggle('ativo');
    if (formAgendamento.classList.contains('ativo')) {
      formAgendamento.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});
